/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

/**
 * An application that lets you input multiple choice quiz questions,
 * then tests you on them.
 * @author elima
 */

import java.util.Scanner;

class Question {
    public static int totalQuestions;
    public static int totalAnswers;
}

public class Quiz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Question quiz;
        int i;
        Scanner sc = new Scanner(System.in);
        //Get quiz questions and answers.
        //Get number of questions.
        System.out.println("How many questions does your quiz have?");
        quiz.totalQuestions = sc.nextInt();
        System.out.println("How many choices will each question have?");
        quiz.totalAnswers = sc.nextInt();
        System.out.println("Your quiz will have " + totalQuestions + " questions.");
        System.out.println("Each question will have " + totalAnswers + " answers.");
        
        //Get each question.
        for (i = 1; i <= totalQuestions; i++)
        {
            System.out.println("What is question " + i + "?");
        }
        
        //TODO Ask each question and get each answer.
        //(maybe randomize question order in the future?)
        
        //TODO Provide grade and offer to retake quiz.
        
    }
    
}
