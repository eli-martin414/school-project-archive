/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworld;

/**
 * This program is notes from the tutorial located at:
 * https://www.w3schools.com/java/default.asp
 * This particular program covers Java syntax, comments, and variables.
 * @author elima
 */

//This is a class.
public class HelloWorld {

    /**
     * @param args the command line arguments
     */
    
    //This is a method. (The method "main" to be exact.)
    public static void main(String[] args) {
        //Print "Hello World".
        System.out.println("Hello World!");
        //Print a second line.
        System.out.println("This is a second line from Eli.");
        /*
        This is a multi-line comment,
        just to remind you how these work.
        */
        System.out.println("This is a third line.");
        System.out.println("This is to test the compiler.");
        
        /* This section will show you
        different kinds of variables. */
        
        //String stores text.
        String exampleString = "String exmaple.";
        
        //int stores 32-bit whole signed integers
        // -2 147 483 648 to 2 147 483 647
        int exampleInteger = -365;
        
        //float stores signed floating point numbers with decimals
        //also a 32-bit, like int, but with a much larger range
        //when a float is declared, must be followed by an f
        float exampleFloat = 3.14159265358979323846f;
        
        //char stores a single character
        char exampleChar = 'c';
        
        //boolean stores true or false
        //unlike C, this does not convert to 0 or 1 at the language level
        boolean exampleBoolean = true;
        
        /* Manipulating variables */
        
        //You don't have to assign a variable a value when you declare it.
        int undeclaredInt;
        //You can add the value later.
        undeclaredInt = 5;
        
        //Using final will make a variable read only
        int exampleFinal = 5;
        //now exampleFinal = 6; will generate an error
        
        //Using + will combine either text and variables,
        //or variables with other variables.
        //For strings, they work like this:
        String firstName = "John";
        //Now to print someone's name, you can print:
        System.out.println("Hello, " + firstName);
        String lastName = "Doe";
        //Or you can combine both variables into one:
        String fullName = firstName + ' ' + lastName;
        System.out.println ("Your full name is: " + fullName);
        //For numerical values, + works as a mathematical operator.
        int four = 4;
        int five = 5;
        System.out.println(four + five);
        int six = four + five;
        
        //You can declare multiple variables in a comma list:
        int a = 5, b = 6, c = 7;
        
    }
    
}
